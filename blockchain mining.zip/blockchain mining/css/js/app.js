let miningSimulator = new MiningSimulator();
let hashAttempts = [];
let maxHashEntries = 50;

// DOM elements
const elements = {
    blockIndex: document.getElementById('blockIndex'),
    previousHash: document.getElementById('previousHash'),
    blockData: document.getElementById('blockData'),
    difficulty: document.getElementById('difficulty'),
    mineBtn: document.getElementById('mineBtn'),
    stopBtn: document.getElementById('stopBtn'),
    miningStatus: document.getElementById('miningStatus'),
    currentNonce: document.getElementById('currentNonce'),
    attempts: document.getElementById('attempts'),
    timeElapsed: document.getElementById('timeElapsed'),
    hashRate: document.getElementById('hashRate'),
    results: document.getElementById('results'),
    winningHash: document.getElementById('winningHash'),
    finalNonce: document.getElementById('finalNonce'),
    totalAttempts: document.getElementById('totalAttempts'),
    miningTime: document.getElementById('miningTime'),
    avgHashRate: document.getElementById('avgHashRate'),
    hashList: document.getElementById('hashList')
};

// Initialize the application
function initializeApp() {
    // Set default values
    elements.blockData.value = "Alice->Bob: 5 BTC\nCharlie->Dave: 2.5 BTC\nEve->Frank: 1.2 BTC";
    elements.previousHash.value = "000abc123def456789abcdef123456789abcdef123456789abcdef123456789ab";
    
    updateHashAttempts();
}

// Start mining process
async function startMining() {
    const blockData = {
        index: parseInt(elements.blockIndex.value),
        data: elements.blockData.value,
        previousHash: elements.previousHash.value
    };
    
    const difficulty = parseInt(elements.difficulty.value);
    
    // Reset UI
    elements.mineBtn.disabled = true;
    elements.stopBtn.disabled = false;
    elements.results.style.display = 'none';
    hashAttempts = [];
    updateHashAttempts();
    
    // Update status
    updateMiningStatus("Mining in progress...", {
        nonce: 0,
        attempts: 0,
        time: 0
    });

    try {
        const result = await miningSimulator.startMining(blockData, difficulty, {
            onProgress: updateMiningProgress,
            onComplete: onMiningComplete,
            onHashAttempt: addHashAttempt
        });
        
        if (!result.success) {
            updateMiningStatus("Mining stopped by user", {
                nonce: result.nonce,
                attempts: result.attempts,
                time: result.time
            });
        }
    } catch (error) {
        console.error('Mining error:', error);
        updateMiningStatus("Mining error occurred", {
            nonce: 0,
            attempts: 0,
            time: 0
        });
    } finally {
        elements.mineBtn.disabled = false;
        elements.stopBtn.disabled = true;
    }
}

// Stop mining process
function stopMining() {
    miningSimulator.stopMining();
    elements.stopBtn.disabled = true;
}

// Update mining progress
function updateMiningProgress(progress) {
    updateMiningStatus("Mining in progress...", progress);
}

// Update mining status display
function updateMiningStatus(status, data) {
    const statusHeader = elements.miningStatus.querySelector('h3');
    statusHeader.textContent = `Mining Status: ${status}`;
    
    elements.currentNonce.textContent = data.nonce.toLocaleString();
    elements.attempts.textContent = data.attempts.toLocaleString();
    elements.timeElapsed.textContent = miningSimulator.formatTime(data.time);
    
    const hashRate = data.time > 0 ? (data.attempts / data.time) * 1000 : 0;
    elements.hashRate.textContent = miningSimulator.formatHashRate(hashRate);
}

// Handle mining completion
function onMiningComplete(result) {
    // Update final status
    updateMiningStatus("Successfully mined!", {
        nonce: result.nonce,
        attempts: result.attempts,
        time: result.time
    });
    
    // Show results
    elements.results.style.display = 'block';
    elements.winningHash.textContent = result.hash;
    elements.finalNonce.textContent = result.nonce.toLocaleString();
    elements.totalAttempts.textContent = result.attempts.toLocaleString();
    elements.miningTime.textContent = miningSimulator.formatTime(result.time);
    
    const avgHashRate = (result.attempts / result.time) * 1000;
    elements.avgHashRate.textContent = miningSimulator.formatHashRate(avgHashRate);
    
    // Add successful hash attempt
    addHashAttempt({
        nonce: result.nonce,
        hash: result.hash,
        success: true
    });
}

// Add hash attempt to display
function addHashAttempt(attempt) {
    hashAttempts.unshift(attempt);
    
    // Limit the number of entries
    if (hashAttempts.length > maxHashEntries) {
        hashAttempts = hashAttempts.slice(0, maxHashEntries);
    }
    
    updateHashAttempts();
}

// Update hash attempts display
function updateHashAttempts() {
    elements.hashList.innerHTML = '';
    
    hashAttempts.forEach(attempt => {
        const entry = document.createElement('div');
        entry.className = `hash-entry ${attempt.success ? 'success' : ''}`;
        
        const nonceSpan = document.createElement('span');
        nonceSpan.className = 'nonce-number';
        nonceSpan.textContent = `Nonce: ${attempt.nonce.toLocaleString()}`;
        
        const hashSpan = document.createElement('span');
        hashSpan.className = 'hash-value';
        hashSpan.textContent = attempt.hash;
        
        const statusSpan = document.createElement('span');
        statusSpan.className = `hash-status ${attempt.success ? 'success' : 'failed'}`;
        statusSpan.textContent = attempt.success ? '✅ SUCCESS' : '❌ FAILED';
        
        entry.appendChild(nonceSpan);
        entry.appendChild(hashSpan);
        entry.appendChild(statusSpan);
        
        elements.hashList.appendChild(entry);
    });
}

// Initialize the app when the page loads
document.addEventListener('DOMContentLoaded', initializeApp);
