class Block {
    constructor(index, timestamp, data, previousHash = '') {
        this.index = index;
        this.timestamp = timestamp;
        this.data = data;
        this.previousHash = previousHash;
        this.nonce = 0;
        this.hash = this.calculateHash();
    }

    calculateHash() {
        const blockString = this.index + 
                          this.timestamp + 
                          JSON.stringify(this.data) + 
                          this.previousHash + 
                          this.nonce;
        
        return this.sha256(blockString);
    }

    async mineBlock(difficulty, onProgress = null, shouldStop = () => false) {
        const target = Array(difficulty + 1).join("0");
        const startTime = Date.now();
        let attempts = 0;

        while (this.hash.substring(0, difficulty) !== target) {
            if (shouldStop()) {
                return {
                    success: false,
                    attempts,
                    time: Date.now() - startTime,
                    nonce: this.nonce
                };
            }

            this.nonce++;
            attempts++;
            this.hash = this.calculateHash();

            if (onProgress && attempts % 1000 === 0) {
                await new Promise(resolve => {
                    setTimeout(() => {
                        onProgress({
                            nonce: this.nonce,
                            attempts,
                            hash: this.hash,
                            time: Date.now() - startTime
                        });
                        resolve();
                    }, 1);
                });
            }
        }

        const endTime = Date.now();
        return {
            success: true,
            attempts,
            time: endTime - startTime,
            nonce: this.nonce,
            hash: this.hash
        };
    }

    // Simple SHA-256 implementation for demo purposes
    sha256(message) {
        const msgBuffer = new TextEncoder().encode(message);
        return crypto.subtle.digest('SHA-256', msgBuffer).then(hashBuffer => {
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        });
    }

    // Synchronous version for immediate hashing
    sha256Sync(message) {
        // This is a simplified hash function for demo purposes
        // In a real implementation, you'd use a proper SHA-256 library
        let hash = 0;
        for (let i = 0; i < message.length; i++) {
            const char = message.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        
        // Convert to hex and pad to simulate SHA-256 output
        let hex = Math.abs(hash).toString(16);
        while (hex.length < 8) {
            hex = '0' + hex;
        }
        
        // Add random padding to make it look more like SHA-256
        const padding = Math.random().toString(16).substr(2, 56);
        return hex + padding.substring(0, 56);
    }

    calculateHashSync() {
        const blockString = this.index + 
                          this.timestamp + 
                          JSON.stringify(this.data) + 
                          this.previousHash + 
                          this.nonce;
        
        return this.sha256Sync(blockString);
    }
}