class MiningSimulator {
    constructor() {
        this.isMining = false;
        this.currentBlock = null;
        this.startTime = null;
        this.stopRequested = false;
    }

    async startMining(blockData, difficulty, callbacks = {}) {
        if (this.isMining) return;
        
        this.isMining = true;
        this.stopRequested = false;
        this.startTime = Date.now();
        
        const { onProgress, onComplete, onHashAttempt } = callbacks;
        
        // Create new block
        this.currentBlock = new Block(
            blockData.index,
            new Date().toISOString(),
            blockData.data,
            blockData.previousHash
        );

        try {
            const result = await this.currentBlock.mineBlock(
                difficulty,
                (progress) => {
                    if (onProgress) onProgress(progress);
                    if (onHashAttempt) {
                        onHashAttempt({
                            nonce: progress.nonce,
                            hash: progress.hash,
                            success: false
                        });
                    }
                },
                () => this.stopRequested
            );

            this.isMining = false;
            
            if (result.success && onComplete) {
                onComplete({
                    ...result,
                    block: this.currentBlock
                });
            }
            
            return result;
        } catch (error) {
            this.isMining = false;
            throw error;
        }
    }

    stopMining() {
        this.stopRequested = true;
        this.isMining = false;
    }

    calculateDifficultyEstimate(difficulty) {
        return Math.pow(16, difficulty);
    }

    formatHashRate(hashesPerSecond) {
        if (hashesPerSecond < 1000) {
            return `${hashesPerSecond.toFixed(0)} H/s`;
        } else if (hashesPerSecond < 1000000) {
            return `${(hashesPerSecond / 1000).toFixed(1)} KH/s`;
        } else {
            return `${(hashesPerSecond / 1000000).toFixed(1)} MH/s`;
        }
    }

    formatTime(milliseconds) {
        if (milliseconds < 1000) {
            return `${milliseconds}ms`;
        } else if (milliseconds < 60000) {
            return `${(milliseconds / 1000).toFixed(2)}s`;
        } else {
            const minutes = Math.floor(milliseconds / 60000);
            const seconds = ((milliseconds % 60000) / 1000).toFixed(0);
            return `${minutes}m ${seconds}s`;
        }
    }
}
