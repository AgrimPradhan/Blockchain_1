class Blockchain {
    constructor() {
        this.chain = [this.createGenesisBlock()];
        this.difficulty = 4;
        this.miningReward = 100;
    }

    createGenesisBlock() {
        const genesisBlock = new Block(0, "01/01/2025", "Genesis Block", "0");
        genesisBlock.hash = genesisBlock.calculateHashSync();
        return genesisBlock;
    }

    getLatestBlock() {
        return this.chain[this.chain.length - 1];
    }

    addBlock(newBlock) {
        newBlock.previousHash = this.getLatestBlock().hash;
        newBlock.hash = newBlock.calculateHashSync();
        this.chain.push(newBlock);
    }

    isChainValid() {
        for (let i = 1; i < this.chain.length; i++) {
            const currentBlock = this.chain[i];
            const previousBlock = this.chain[i - 1];

            if (currentBlock.hash !== currentBlock.calculateHashSync()) {
                return false;
            }

            if (currentBlock.previousHash !== previousBlock.hash) {
                return false;
            }
        }
        return true;
    }

    getChainStats() {
        return {
            length: this.chain.length,
            difficulty: this.difficulty,
            isValid: this.isChainValid(),
            totalBlocks: this.chain.length
        };
    }
}